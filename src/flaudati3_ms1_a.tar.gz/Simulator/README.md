# Weight Stationary Tiled Systolic Array Simulator

I built a cycle-level simulator of the project's weight-stationary systolic array in C. The simulator does tiled matrix multiplication (GEMM) on an `R x C` grid of processing elements and computes `C = A x B` where A is an activation matrix of dimensions `M x K`, B is the weight matrix of dimensions `K x N`, and C is the result matrix of dimensions `M x N`. The default operating mode saturates to 16-bit partial sums and 8-bit outputs but these are parameterizable. A Python implementation of matrix multiplication using NUMPY is also included to verify this simulator. The simulator operates at a bit-level, simulating the individual PEs and accounting for reading from memory.

## Requirements

- A prebuilt `sim.out` for the ECE Linux servers is included, so nothing is needed just to run the simulator.
- To rebuild from source: a C11 compiler (`cc`/`gcc`) and `make`.
- Python 3 and numpy (listed in `requirements.txt`), **only** to run the test script (`test_sim.py`). The simulator itself has no Python dependency.

## Building

The included `sim.out` was built on the ECE server. To rebuild it:

```
make clean
make
```

This compiles the five `.c` files into `sim.out`. The Makefile links statically (`-static`) when the system has the static C library. The ECE servers do not have it, so there `sim.out` is linked against the system C library (glibc) only. The simulator uses no other libraries. All files needed to build are included in this folder.

To install the test dependencies:

```
pip install -r requirements.txt
```

## Running the Simulator

```
./run.sh <Num Array Rows> <Num Array Cols> <M> <N> <K> <Path to A> <Path to B> <Path to write C>
```

Example:

```
./run.sh 4 4 8 8 8 A_matrix_8.txt B_matrix_8.txt C_out.txt
```

`run.sh` runs the included `sim.out` (it only builds it with `make` if the binary is missing) with the given arguments. The simulator rejects the run with a usage message and a nonzero exit code if:
- `M` or `K` is not a multiple of the number of array rows
- `N` is not a multiple of the number of array columns
- any dimension is not a positive integer

## File Format

A, B and C use the same text format as the files in `doc/examples`:
- one matrix row per line
- elements separated by spaces
- each element is a 2-digit, two's complement hex value (for example `FE` = -2 and `7F` = 127)

A is read as `M x K`, B as `K x N`, and C is written as `M x N`.

## Code Organization

| File | Purpose |
|------|---------|
| `run.sh` | Runs `sim.out` with the 8 arguments (builds it first if it is missing). |
| `sim.out` | Prebuilt simulator binary for the ECE Linux servers. |
| `main.c` | Parses arguments, loads A and B, runs the tiled GEMM, and writes the C output matrix. |
| `config.c/.h` | Parses and checks the command line arguments into `sim_config_t`. Defines the bit widths `OUT_WIDTH_BITS` (8) and `PSUM_WIDTH_BITS` (16). |
| `mem.c/.h` | Matrix and partial sum memory structures, reading and writing matrix files, sign extension, and saturation helpers. |
| `PE.c/.h` | Model of one PE. Holds a stationary weight and does one multiply-accumulate (MAC) per cycle. |
| `systolic.c/.h` | A grid of PEs. Performs weight tile loading, single-cycle stepping, streaming one tile with input skew, and the top-level tiling controller. |
| `Makefile` | Builds `sim.out` from the C sources (statically linked when possible). |
| `requirements.txt` | Python packages needed by `test_sim.py`. |
| `test_sim.py` | **For testing the simulator functionality only.** Checks the simulator's output against a numpy reference model (see [Testing](#testing)). It is not part of the simulator. |

## Key Data Structures

- **`pe_t`** (PE.h): one PE. Holds its stationary `weight` and two output registers, `act_out` (passed east) and `psum_out` (passed south). Each cycle it computes `psum_out = psum_in + weight * act_in`. Values are `int64_t`, so the array keeps full precision.
- **`systolic_array_t`** (systolic.h): a 2D grid of `pe_t` plus a cycle counter.
- **`matrix_t`** (mem.h): a row-major matrix used for A, B and C.
- **`psum_mem_t`** (mem.h): the `M x N` partial sum memory. Every add into it saturates to signed 16 bits.
- **`sim_config_t`** (config.h): the array size, M/N/K, and the file paths from the command line.

## How It Works

1. **Load weights:** a 4x4 (R x C) tile of B is loaded into the PEs. It stays there while activations stream through.
2. **Stream activations:** a tile of A enters from the west edge. Row `i` is delayed by `i` cycles so the data lines up diagonally. This skew is done while streaming, not stored in memory. Partial sums flow down each column and come out the bottom.
3. **Accumulate:** each output tile is added into partial sum memory (saturating to 16 bits).
4. **Tiling:** the loop order is N tiles, then K tiles, then M tiles. Each weight tile is loaded only once, and every activation tile that needs it streams through while it is loaded.
5. **Output:** after all K tiles are added, each value is saturated to signed 8 bits and written to C.

`systolic_step` updates the PEs from the bottom-right corner to the top-left. Each PE then reads its neighbors' values from the previous cycle, like registers on a clock edge.

## Testing

`test_sim.py` is only used to test the C simulator. It is not part of the simulator. It generates random and edge-case matrices, runs `run.sh`, and checks C against a numpy reference that does the same 16-bit partial sum and 8-bit output saturation.

```
python3 test_sim.py          # full test suite
python3 test_sim.py --quick  # shorter run
```
